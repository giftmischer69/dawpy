from dawpy import cli

cli.cli()
