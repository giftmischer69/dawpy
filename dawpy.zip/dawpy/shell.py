from cmd import Cmd
from dawpy.daw import Daw


class View:
    def print_daw(self, daw):
        parsed = json.loads(daw.json())
        print(json.dumps(parsed, indent=4, sort_keys=True))


class Shell(Cmd):
    def __init__(self, headless):
        super().__init__()
        self.prompt = "dsh>"
        self.daw = Daw()

    def do_q(self, line):
        """ Quits the shell """
        return True

    def do_pd(self, line):
        """ Prints the daw """
        self.view.print_daw(self.daw)
