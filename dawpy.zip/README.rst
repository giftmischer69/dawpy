===============================
dawpy
===============================


.. image:: https://img.shields.io/travis/giftmischer69/dawpy.svg
        :target: https://travis-ci.org/giftmischer69/dawpy
.. image:: https://circleci.com/gh/giftmischer69/dawpy.svg?style=svg
    :target: https://circleci.com/gh/giftmischer69/dawpy
.. image:: https://codecov.io/gh/giftmischer69/dawpy/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/giftmischer69/dawpy


python digital audio workstation suite

- dawpy api
- dawpy cli

  - dawpy shell
  - dawpy api-server
  - dawpy web-frontend