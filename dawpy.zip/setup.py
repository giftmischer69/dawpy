from setuptools import setup
import versioneer

requirements = [
    "typer",
    "pydantic"
    # package requirements go here
]

setup(
    name="dawpy",
    version=versioneer.get_version(),
    cmdclass=versioneer.get_cmdclass(),
    description="python digital audio workstation suite",
    license="MIT",
    author="giftmischer69",
    author_email="giftmischer69@pm.me",
    url="https://github.com/giftmischer69/dawpy",
    packages=["dawpy"],
    entry_points={"console_scripts": ["dawpy=dawpy.cli:cli"]},
    install_requires=requirements,
    keywords="dawpy",
    classifiers=[
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
    ],
)
